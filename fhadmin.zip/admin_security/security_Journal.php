<?php include('../admin_config/config.php');?>
<!doctype html>
<html>
  
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>番号CMS管理中心</title>
    <meta name="description" content="这是一个 index 页面">
    <meta name="keywords" content="index">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/png" href="<?php echo CMS_ADMIN_url;?>assets/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo CMS_ADMIN_url;?>assets/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-title" content="Amaze UI" />
    <link rel="stylesheet" href="<?php echo CMS_ADMIN_url;?>assets/css/amazeui.min.css" />
    <link rel="stylesheet" href="<?php echo CMS_ADMIN_url;?>assets/css/admin.css">
    <link rel="stylesheet" href="<?php echo CMS_ADMIN_url;?>assets/css/app.css">

  </head>
  
  <body data-type="index">
	<?php include('../admin_config/admin_top.php');;?>
    <div class="tpl-page-container tpl-page-header-fixed">
	<?php include('../admin_config/admin_list.php');;?>
        <div class="tpl-content-wrapper">

            <ol class="am-breadcrumb">
                <li><a href="javascript:;" class="am-icon-home">首页</a></li>
                <li>安全管理</li>
				 <li class="am-active">登陆日志</li>
            </ol>
<div class="tpl-portlet-components">
                <div class="portlet-title">
                    <div class="caption font-green bold">
                        <span class="am-icon-code"></span> 登陆日志
                    </div>



                </div>
                <div class="tpl-block">
                    <div class="am-g">
                        <div class="am-u-sm-12 am-u-md-6">
                            <div class="am-btn-toolbar">
                                <div class="am-btn-group am-btn-group-xs">
                                    <a href="?sc=6000&id=1"><button type="button" class="am-btn am-btn-default am-btn-success"><span class="am-icon-plus"></span> 清空</button></a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="am-g">
                        <div class="am-u-sm-12">
                            <form class="am-form">
                                <table class="am-table am-table-striped am-table-hover table-main">
                                    <thead>
                                        <tr>
                                            <th class="table-title">登陆IP</th>
											 <th class="table-date am-hide-sm-only">登陆时间</th>

                                        </tr>
                                    </thead>
                                    <tbody>	
									
<?php	
$ad_top_json_url=CMS_ROOT."Basicsetup/Journal.php";
error_reporting(E_ALL^E_NOTICE^E_WARNING);
header("Content-type: text/html; charset=utf-8");
include('../../class/class_txttest.php');
$txt = new  TxtDB($ad_top_json_url);
$bankinfo = array();
//$txt::insert($bankinfo);  //增
//$txt::alter($bankinfo); //改
//$txt::delete(105); //删
//$date = $txt::select(105); //查
//var_dump($date);
$order = "desc"; // asc 升序 desc 降序
$txt::show($order); //显示所有
$user=$txt::show($order);
$count=count($user);

for ($x=0; $x<=$count-1; $x++) {
	$str = explode('|', $user[$x]);
     $ad_top_id=$str['0'];	
     $ad_top_url=$str['1'];
	$ad_top_pic=$str['2'];
	$ad_top_md=$str['3'];
	$ad_top_time=$str['4'];
	
?>
                                        <tr>
                                            <td><a href="javascript:;"><?php echo $ad_top_url?></a></td>
											<td class="am-hide-sm-only"><?php echo $ad_top_time?></td>

                                        </tr>

<?php	
	
} 

?>	

                                    </tbody>
                                </table>
                                <hr>

                            </form>
                        </div>

                    </div>
                </div>
                <div class="tpl-alert"></div>
            </div>        </div>
				<?php include('../admin_config/admin_foot.php');?>
    </div>
<?php
if (isset($_GET['sc']) && isset($_GET['id']) ) {	
function post_input($data){$data = stripslashes($data);$data = htmlspecialchars($data);return $data;}	
$sc = post_input($_GET["sc"]);	
$id = post_input($_GET["id"]);	
if($sc =="6000"){
	$path=$ad_top_json_url;
$fh = fopen($path, "r+"); 

if( flock($fh, LOCK_EX) ){//加写锁 

ftruncate($fh,0); // 将文件截断到给定的长度 
rewind($fh); // 倒回文件指针的位置 
flock($fh, LOCK_UN); //解锁 





} 
$txt = "<?php exit()?>\n";
fwrite($fh, $txt);

fclose($fh); 	
?>
	<script language="javascript"> 
	<!-- 

	alert("恭喜删除成功！"); 
	window.location.href="security_Journal.php" 

	--> 
	</script> 
<?php
	}
}	
?>	
	
    <script src="<?php echo CMS_ADMIN_url;?>assets/js/jquery.min.js"></script>
    <script src="<?php echo CMS_ADMIN_url;?>assets/js/amazeui.min.js"></script>
    <script src="<?php echo CMS_ADMIN_url;?>assets/js/iscroll.js"></script>
    <script src="<?php echo CMS_ADMIN_url;?>assets/js/app.js"></script>
  </body>

</html>